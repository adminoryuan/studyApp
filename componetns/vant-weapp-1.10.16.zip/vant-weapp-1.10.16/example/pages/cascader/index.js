import Page from '../../common/page';

Page();
