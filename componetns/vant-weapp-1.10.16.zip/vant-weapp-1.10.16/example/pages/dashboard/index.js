import list from '../../config';
import Page from '../../common/page';

Page({
  data: {
    list,
  },
});
