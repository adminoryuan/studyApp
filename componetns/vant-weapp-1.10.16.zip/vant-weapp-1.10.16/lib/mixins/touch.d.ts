export declare const touch: string;
